echo "Comparing ground truth outputs to new processor"
cd ~/4824CompArch/project3
# This only runs *.s files. How could you add *.c files?

source setup-path.sh

all_passed=true


for source_file in programs/*.{s,c}; do
if [ "$source_file" = "programs/crt.s" ]
then
continue
fi
program=$(echo "$source_file" | cut -d '.' -f1 | cut -d '/' -f 2)
echo "Running $program"
make $program.out > /dev/null

#echo "Comparing writeback output for $program"
diff output/$program.wb correct_output33/$program.wb > /dev/null
result_wb=$?

if [ $result_wb -eq 0 ]; then
    echo -e "\e[32mwb_passed\e[0m"
else
    echo -e "\e[31mwb_failed\e[0m"
    all_passed=false
fi

#echo "Comparing memory output for $program"
grep '^@@@' output/$program.out > output/"$program"_mem.out
grep '^@@@' correct_output33/$program.out > output/"$program"_mem_ori.out
diff output/"$program"_mem.out output/"$program"_mem_ori.out > /dev/null
result_out=$?

#echo "Printing Passed or Failed"
if [ $result_out -eq 0 ]; then
    echo -e "\e[32mout_passed\e[0m"
else
     echo -e "\e[31mout_failed\e[0m"
    all_passed=false
fi
done


if $all_passed ; then
    echo "All Passed"
else
    echo "Failed"
fi